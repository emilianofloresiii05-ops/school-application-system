<?php
declare(strict_types=1);
/**
 * Data Retention & Archival Maintenance Script (Data Privacy Act of 2012 Compliance)
 * Run via CLI cron job: php tools/retention_cleanup.php
 * Or via authorized GET/POST with ?secret=...
 */
$config = require __DIR__ . '/../config/config.php';
if (PHP_SAPI !== 'cli') {
    $secret = $_GET['secret'] ?? $_POST['secret'] ?? '';
    $expected = $config['retention']['cron_secret'] ?? '';
    if ($expected === '' || !hash_equals($expected, (string)$secret)) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Unauthorized maintenance trigger']);
        exit;
    }
}

$d = $config['db'];
$pdo = new PDO("mysql:host={$d['host']};dbname={$d['name']};charset={$d['charset']}", $d['user'], $d['pass'], [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);

$loginMins  = (int)($config['retention']['login_attempt_minutes'] ?? 15);
$archiveDays = (int)($config['retention']['archive_logs_days'] ?? 180);
$notifDays  = (int)($config['retention']['purge_read_notifications_days'] ?? 90);

$pdo->beginTransaction();

// 1. Purge expired login throttle entries
$delAttempts = $pdo->prepare("DELETE FROM login_attempts WHERE attempted_at < (NOW() - INTERVAL ? MINUTE)");
$delAttempts->execute([$loginMins]);
$purgedAttempts = $delAttempts->rowCount();

// 2. Purge expired/used password reset tokens
$delResets = $pdo->query("DELETE FROM password_resets WHERE expires_at < NOW() OR used_at IS NOT NULL");
$purgedResets = $delResets->rowCount();

// 3. Archive old activity logs to archived_activity_logs before pruning main table
$archStmt = $pdo->prepare("
    INSERT IGNORE INTO archived_activity_logs (id, actor_id, action, target_type, target_id, ip_address, created_at)
    SELECT id, actor_id, action, target_type, target_id, ip_address, created_at
    FROM activity_logs
    WHERE created_at < (NOW() - INTERVAL ? DAY)
");
$archStmt->execute([$archiveDays]);
$archivedLogs = $archStmt->rowCount();

$delLogs = $pdo->prepare("DELETE FROM activity_logs WHERE created_at < (NOW() - INTERVAL ? DAY)");
$delLogs->execute([$archiveDays]);

// 4. Purge old read notifications
$delNotifs = $pdo->prepare("DELETE FROM notifications WHERE is_read = 1 AND created_at < (NOW() - INTERVAL ? DAY)");
$delNotifs->execute([$notifDays]);
$purgedNotifs = $delNotifs->rowCount();

$pdo->commit();

$summary = [
    'status' => 'ok',
    'executed_at' => date('Y-m-d H:i:s'),
    'purged_login_attempts' => $purgedAttempts,
    'purged_reset_tokens' => $purgedResets,
    'archived_activity_logs' => $archivedLogs,
    'purged_read_notifications' => $purgedNotifs
];

if (PHP_SAPI === 'cli') {
    echo json_encode($summary, JSON_PRETTY_PRINT) . PHP_EOL;
} else {
    header('Content-Type: application/json');
    echo json_encode($summary);
}
