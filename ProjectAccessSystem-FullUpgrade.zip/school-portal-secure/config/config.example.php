<?php
// Copy to config.php and set credentials from your local/server environment.
return [
  'db' => [
    'host' => '127.0.0.1', 'name' => 'school_project_portal',
    'user' => 'school_portal_user', 'pass' => 'CHANGE_THIS_DATABASE_PASSWORD',
    'charset' => 'utf8mb4'
  ],
  'app' => [
    'school_id' => '342566',
    'session_name' => 'SJLSHS_PORTAL',
    'base_url' => 'http://localhost/school-portal-secure'
  ],
  'mail' => [
    'enabled' => false, // Set to true once SMTP / local sendmail is configured
    'from_email' => 'noreply@sjlshs.edu.ph',
    'from_name' => 'San Jose-Litex SHS Project Portal',
    'smtp_host' => 'smtp.gmail.com',
    'smtp_port' => 587,
    'smtp_user' => '',
    'smtp_pass' => ''
  ],
  'retention' => [
    'login_attempt_minutes' => 15,
    'archive_logs_days' => 180,
    'purge_read_notifications_days' => 90,
    'cron_secret' => 'CHANGE_THIS_MAINTENANCE_SECRET'
  ]
];
